﻿namespace Final
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.label6 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.colorDialog1 = new System.Windows.Forms.ColorDialog();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label5 = new System.Windows.Forms.Label();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.button6 = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.button7 = new System.Windows.Forms.Button();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.button8 = new System.Windows.Forms.Button();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label11 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.radioButton6 = new System.Windows.Forms.RadioButton();
			this.radioButton8 = new System.Windows.Forms.RadioButton();
			this.label10 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.button9 = new System.Windows.Forms.Button();
			this.button10 = new System.Windows.Forms.Button();
			this.label12 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.label13 = new System.Windows.Forms.Label();
			this.trackBar1 = new System.Windows.Forms.TrackBar();
			this.label14 = new System.Windows.Forms.Label();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			this.label15 = new System.Windows.Forms.Label();
			this.button11 = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.label16 = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.label17 = new System.Windows.Forms.Label();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.button12 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.label18 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(482, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "👆 Formun başlığı Text özelliği ile değişir";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 32);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(736, 23);
			this.label2.TabIndex = 1;
			this.label2.Text = "StartPosition özelliği formun hangi konumda başliyacağını belirtir";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 55);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(648, 23);
			this.label3.TabIndex = 2;
			this.label3.Text = "MaximizeBox özelliği formun tam ekran yapılmasını engeller";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(53, 122);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(204, 31);
			this.textBox1.TabIndex = 3;
			this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(7, 97);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(250, 23);
			this.label4.TabIndex = 4;
			this.label4.Text = "Başlığı değiştir";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// toolTip1
			// 
			this.toolTip1.AutoPopDelay = 300;
			this.toolTip1.InitialDelay = 500;
			this.toolTip1.ReshowDelay = 100;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(290, 97);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(272, 23);
			this.label6.TabIndex = 6;
			this.label6.Text = "Seçilen rengi değiştir";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button1
			// 
			this.button1.ForeColor = System.Drawing.Color.Black;
			this.button1.Location = new System.Drawing.Point(340, 123);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(222, 31);
			this.button1.TabIndex = 7;
			this.button1.Text = "Renk seç";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// colorDialog1
			// 
			this.colorDialog1.FullOpen = true;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Black;
			this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox1.Location = new System.Drawing.Point(584, 123);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(204, 57);
			this.pictureBox1.TabIndex = 9;
			this.pictureBox1.TabStop = false;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(580, 97);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(208, 23);
			this.label5.TabIndex = 10;
			this.label5.Text = "Seçilen renk";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button2
			// 
			this.button2.ForeColor = System.Drawing.Color.Black;
			this.button2.Location = new System.Drawing.Point(630, 186);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(158, 31);
			this.button2.TabIndex = 11;
			this.button2.Text = "İkonu göster";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.ForeColor = System.Drawing.Color.Black;
			this.button3.Location = new System.Drawing.Point(584, 187);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(40, 30);
			this.button3.TabIndex = 12;
			this.button3.Text = "ℹ️";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.ForeColor = System.Drawing.Color.Black;
			this.button4.Location = new System.Drawing.Point(294, 124);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(40, 30);
			this.button4.TabIndex = 13;
			this.button4.Text = "ℹ️";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button5
			// 
			this.button5.ForeColor = System.Drawing.Color.Black;
			this.button5.Location = new System.Drawing.Point(7, 122);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(40, 30);
			this.button5.TabIndex = 14;
			this.button5.Text = "ℹ️";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// comboBox1
			// 
			this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(7, 277);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(250, 31);
			this.comboBox1.TabIndex = 15;
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(12, 177);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(473, 23);
			this.label7.TabIndex = 16;
			this.label7.Text = "ComboBox ve ListBox a Eleman Ekle";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button6
			// 
			this.button6.ForeColor = System.Drawing.Color.Black;
			this.button6.Location = new System.Drawing.Point(7, 202);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(40, 30);
			this.button6.TabIndex = 17;
			this.button6.Text = "ℹ️";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(53, 203);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(204, 31);
			this.textBox2.TabIndex = 18;
			this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
			// 
			// button7
			// 
			this.button7.ForeColor = System.Drawing.Color.Black;
			this.button7.Location = new System.Drawing.Point(7, 240);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(250, 31);
			this.button7.TabIndex = 19;
			this.button7.Text = "Ekle";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new System.Drawing.Point(53, 314);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(186, 27);
			this.checkBox1.TabIndex = 20;
			this.checkBox1.Text = "Listeyi Sırala";
			this.checkBox1.UseVisualStyleBackColor = true;
			this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// button8
			// 
			this.button8.ForeColor = System.Drawing.Color.Black;
			this.button8.Location = new System.Drawing.Point(7, 311);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(40, 30);
			this.button8.TabIndex = 21;
			this.button8.Text = "ℹ️";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// listBox1
			// 
			this.listBox1.FormattingEnabled = true;
			this.listBox1.ItemHeight = 23;
			this.listBox1.Location = new System.Drawing.Point(263, 203);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(222, 142);
			this.listBox1.TabIndex = 22;
			this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.label11);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.label8);
			this.panel1.Location = new System.Drawing.Point(491, 223);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(297, 256);
			this.panel1.TabIndex = 23;
			// 
			// label11
			// 
			this.label11.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.label11.Font = new System.Drawing.Font("Consolas", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label11.Location = new System.Drawing.Point(0, 219);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(295, 35);
			this.label11.TabIndex = 20;
			this.label11.Text = "RadioButton grupları farklı panallere ayrılmalıdır";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
			this.panel3.Controls.Add(this.radioButton6);
			this.panel3.Controls.Add(this.radioButton8);
			this.panel3.Controls.Add(this.label10);
			this.panel3.Location = new System.Drawing.Point(4, 142);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(288, 74);
			this.panel3.TabIndex = 19;
			// 
			// radioButton6
			// 
			this.radioButton6.AutoSize = true;
			this.radioButton6.Location = new System.Drawing.Point(199, 31);
			this.radioButton6.Name = "radioButton6";
			this.radioButton6.Size = new System.Drawing.Size(75, 27);
			this.radioButton6.TabIndex = 21;
			this.radioButton6.Text = "Evet";
			this.radioButton6.UseVisualStyleBackColor = true;
			// 
			// radioButton8
			// 
			this.radioButton8.AutoSize = true;
			this.radioButton8.Location = new System.Drawing.Point(15, 31);
			this.radioButton8.Name = "radioButton8";
			this.radioButton8.Size = new System.Drawing.Size(75, 27);
			this.radioButton8.TabIndex = 19;
			this.radioButton8.Text = "Evet";
			this.radioButton8.UseVisualStyleBackColor = true;
			// 
			// label10
			// 
			this.label10.Dock = System.Windows.Forms.DockStyle.Top;
			this.label10.Location = new System.Drawing.Point(0, 0);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(288, 23);
			this.label10.TabIndex = 18;
			this.label10.Text = "Dersten Kaldım mı";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
			this.panel2.Controls.Add(this.radioButton4);
			this.panel2.Controls.Add(this.radioButton3);
			this.panel2.Controls.Add(this.radioButton2);
			this.panel2.Controls.Add(this.radioButton1);
			this.panel2.Controls.Add(this.label9);
			this.panel2.Location = new System.Drawing.Point(4, 26);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(288, 100);
			this.panel2.TabIndex = 18;
			// 
			// radioButton4
			// 
			this.radioButton4.AutoSize = true;
			this.radioButton4.Location = new System.Drawing.Point(155, 61);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.Size = new System.Drawing.Size(119, 27);
			this.radioButton4.TabIndex = 22;
			this.radioButton4.Text = "Internal";
			this.radioButton4.UseVisualStyleBackColor = true;
			this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton3
			// 
			this.radioButton3.AutoSize = true;
			this.radioButton3.Location = new System.Drawing.Point(155, 31);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new System.Drawing.Size(130, 27);
			this.radioButton3.TabIndex = 21;
			this.radioButton3.Text = "Protected";
			this.radioButton3.UseVisualStyleBackColor = true;
			this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton2
			// 
			this.radioButton2.AutoSize = true;
			this.radioButton2.Location = new System.Drawing.Point(15, 63);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(108, 27);
			this.radioButton2.TabIndex = 20;
			this.radioButton2.Text = "Private";
			this.radioButton2.UseVisualStyleBackColor = true;
			this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton1
			// 
			this.radioButton1.AutoSize = true;
			this.radioButton1.Location = new System.Drawing.Point(15, 31);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(97, 27);
			this.radioButton1.TabIndex = 19;
			this.radioButton1.Text = "Public";
			this.radioButton1.UseVisualStyleBackColor = true;
			this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// label9
			// 
			this.label9.Dock = System.Windows.Forms.DockStyle.Top;
			this.label9.Location = new System.Drawing.Point(0, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(288, 23);
			this.label9.TabIndex = 18;
			this.label9.Text = "Erişim Belirliyiciler";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label8
			// 
			this.label8.Dock = System.Windows.Forms.DockStyle.Top;
			this.label8.Font = new System.Drawing.Font("Consolas", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label8.Location = new System.Drawing.Point(0, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(295, 23);
			this.label8.TabIndex = 17;
			this.label8.Text = "Seçenekler";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// checkedListBox1
			// 
			this.checkedListBox1.FormattingEnabled = true;
			this.checkedListBox1.Items.AddRange(new object[] {
            "// ComboBox a eleman ekleme",
            "// ComboBox.Items.Add(eleman);",
            "ComboBox.Items.Add(\"merhaba!\");",
            "merhaba",
            "Yeni Eleman",
            "1",
            "2",
            "3"});
			this.checkedListBox1.Location = new System.Drawing.Point(810, 122);
			this.checkedListBox1.Name = "checkedListBox1";
			this.checkedListBox1.Size = new System.Drawing.Size(387, 160);
			this.checkedListBox1.TabIndex = 24;
			this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
			// 
			// listBox2
			// 
			this.listBox2.FormattingEnabled = true;
			this.listBox2.ItemHeight = 23;
			this.listBox2.Location = new System.Drawing.Point(810, 324);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(387, 142);
			this.listBox2.TabIndex = 25;
			this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
			// 
			// button9
			// 
			this.button9.ForeColor = System.Drawing.Color.Black;
			this.button9.Location = new System.Drawing.Point(854, 287);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(343, 31);
			this.button9.TabIndex = 26;
			this.button9.Text = "Itemleri Aktar veya varsa sil";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// button10
			// 
			this.button10.ForeColor = System.Drawing.Color.Black;
			this.button10.Location = new System.Drawing.Point(810, 288);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(40, 30);
			this.button10.TabIndex = 27;
			this.button10.Text = "ℹ️";
			this.button10.UseVisualStyleBackColor = true;
			this.button10.Click += new System.EventHandler(this.button10_Click);
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(810, 96);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(387, 23);
			this.label12.TabIndex = 28;
			this.label12.Text = "Eleman Aktar Veya Varsa Sil";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(7, 397);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(301, 31);
			this.dateTimePicker1.TabIndex = 29;
			this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(7, 366);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(301, 23);
			this.label13.TabIndex = 30;
			this.label13.Text = "Tarih Seç";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// trackBar1
			// 
			this.trackBar1.Location = new System.Drawing.Point(7, 473);
			this.trackBar1.Maximum = 100;
			this.trackBar1.Name = "trackBar1";
			this.trackBar1.Size = new System.Drawing.Size(297, 56);
			this.trackBar1.TabIndex = 31;
			this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.Both;
			this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(7, 447);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(301, 23);
			this.label14.TabIndex = 32;
			this.label14.Text = "Yüzde yi ayarla";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// progressBar1
			// 
			this.progressBar1.Location = new System.Drawing.Point(310, 473);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(175, 56);
			this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
			this.progressBar1.TabIndex = 33;
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(306, 447);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(179, 23);
			this.label15.TabIndex = 34;
			this.label15.Text = "Yüzde";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button11
			// 
			this.button11.ForeColor = System.Drawing.Color.Black;
			this.button11.Location = new System.Drawing.Point(12, 524);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(40, 30);
			this.button11.TabIndex = 35;
			this.button11.Text = "ℹ️";
			this.button11.UseVisualStyleBackColor = true;
			this.button11.Click += new System.EventHandler(this.button11_Click);
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Location = new System.Drawing.Point(500, 486);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(697, 100);
			this.tabControl1.TabIndex = 36;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.label16);
			this.tabPage1.Location = new System.Drawing.Point(4, 32);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(689, 64);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Tab Page 1";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.ForeColor = System.Drawing.Color.Black;
			this.label16.Location = new System.Drawing.Point(6, 22);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(648, 23);
			this.label16.TabIndex = 1;
			this.label16.Text = "TabControl ün TabPages özelliği ile (2. tab page \'a geçin)";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.label17);
			this.tabPage2.Location = new System.Drawing.Point(4, 25);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(689, 71);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Tab Page 2";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.ForeColor = System.Drawing.Color.Black;
			this.label17.Location = new System.Drawing.Point(3, 23);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(395, 23);
			this.label17.TabIndex = 2;
			this.label17.Text = "... TabControl e Page ekleyebiliriz";
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.button13);
			this.tabPage3.Controls.Add(this.button12);
			this.tabPage3.Location = new System.Drawing.Point(4, 32);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(689, 64);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Ek Sayfalar";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// button12
			// 
			this.button12.BackColor = System.Drawing.Color.Black;
			this.button12.Dock = System.Windows.Forms.DockStyle.Left;
			this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button12.Location = new System.Drawing.Point(0, 0);
			this.button12.Margin = new System.Windows.Forms.Padding(10);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(237, 64);
			this.button12.TabIndex = 0;
			this.button12.Text = "Hakkında Sayfası";
			this.button12.UseVisualStyleBackColor = false;
			this.button12.Click += new System.EventHandler(this.button12_Click);
			// 
			// button13
			// 
			this.button13.BackColor = System.Drawing.Color.Black;
			this.button13.Dock = System.Windows.Forms.DockStyle.Left;
			this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button13.Location = new System.Drawing.Point(237, 0);
			this.button13.Margin = new System.Windows.Forms.Padding(10);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(266, 64);
			this.button13.TabIndex = 1;
			this.button13.Text = "Timer Kullanım Örneği";
			this.button13.UseVisualStyleBackColor = false;
			this.button13.Click += new System.EventHandler(this.button13_Click);
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(984, 9);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(131, 23);
			this.label18.TabIndex = 37;
			this.label18.Text = "Fare Konumu";
			// 
			// label19
			// 
			this.label19.Location = new System.Drawing.Point(984, 32);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(131, 23);
			this.label19.TabIndex = 38;
			this.label19.Text = "0,0";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(10)))));
			this.ClientSize = new System.Drawing.Size(1209, 598);
			this.Controls.Add(this.label19);
			this.Controls.Add(this.label18);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.button11);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.progressBar1);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.trackBar1);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.button10);
			this.Controls.Add(this.button9);
			this.Controls.Add(this.listBox2);
			this.Controls.Add(this.checkedListBox1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.button8);
			this.Controls.Add(this.checkBox1);
			this.Controls.Add(this.button7);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.button6);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.ForeColor = System.Drawing.Color.White;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Başlık";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.LocationChanged += new System.EventHandler(this.Form1_LocationChanged);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ColorDialog colorDialog1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.RadioButton radioButton4;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.RadioButton radioButton6;
		private System.Windows.Forms.RadioButton radioButton8;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.CheckedListBox checkedListBox1;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TrackBar trackBar1;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Timer timer1;
	}
}

